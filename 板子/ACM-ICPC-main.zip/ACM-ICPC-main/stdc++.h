#define _CRT_SECURE_NO_WARNINGS 1
#include <iostream> 　　　//数据流输入／输出
#include <string>　　　　　//字符串类
#include <cmath> 　　　　　//定义数学函数
#include <cstdio> 　　　　 //定义输入／输出函数
#include <cstring> 　　　　//字符串处理
#include <iomanip> 　　　 //参数化输入／输出
#include <iterator>       //STL迭代器
#include <algorithm>　　　  //STL 通用算法
#include <map>　　　　　　 //STL 映射容器
#include <queue>　　　　　 //STL 队列容器
#include <set>　　　　　　 //STL 集合容器
#include <stack>　　　　　 //STL 堆栈容器
#include <vector>　　　　　//STL 动态数组容器
