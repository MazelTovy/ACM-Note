
unsigned xor_n(unsigned n)
 
{
	
	unsigned t = n & 3;
	
	if (t & 1) return t / 2u ^ 1;
	
	return t / 2u ^ n;
	
}
